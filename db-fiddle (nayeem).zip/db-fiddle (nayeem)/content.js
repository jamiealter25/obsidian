// DBFiddle SQL Downloader - Guaranteed Working Version
console.log('DBFiddle Downloader loaded');

// Function to safely get SQL from CodeMirror
function getSQLFromPage() {
  console.log('Getting SQL from page...');
  
  let schemaSQL = '';
  let querySQL = '';
  
  // METHOD 1: Direct CodeMirror instance access (most reliable)
  const codeMirrors = document.querySelectorAll('.CodeMirror');
  console.log('Found', codeMirrors.length, 'CodeMirror editors');
  
  // Log each editor's details
  codeMirrors.forEach((cm, index) => {
    console.log(`Editor ${index}:`, {
      hasCodeMirrorInstance: !!cm.CodeMirror,
      className: cm.className,
      textarea: cm.querySelector('textarea') ? 'Yes' : 'No'
    });
    
    // Try to get value using different methods
    let editorValue = '';
    
    // Method A: Direct CodeMirror instance
    if (cm.CodeMirror) {
      try {
        editorValue = cm.CodeMirror.getValue();
        console.log(`Editor ${index} (CodeMirror.getValue):`, editorValue.length, 'chars');
      } catch (e) {
        console.log(`Editor ${index} CodeMirror.getValue error:`, e.message);
      }
    }
    
    // Method B: Textarea inside CodeMirror
    if (!editorValue) {
      const textarea = cm.querySelector('textarea');
      if (textarea && textarea.value) {
        editorValue = textarea.value;
        console.log(`Editor ${index} (textarea.value):`, editorValue.length, 'chars');
      }
    }
    
    // Method C: Extract from rendered content (last resort)
    if (!editorValue) {
      const lines = cm.querySelectorAll('.CodeMirror-line');
      if (lines.length > 0) {
        editorValue = Array.from(lines)
          .map(line => line.textContent || '')
          .join('\n');
        console.log(`Editor ${index} (extracted text):`, editorValue.length, 'chars');
      }
    }
    
    // Determine if this is schema or query
    // Usually first editor is schema, second is query
    if (index === 0 && editorValue) {
      schemaSQL = editorValue;
    } else if (index === 1 && editorValue) {
      querySQL = editorValue;
    }
  });
  
  // METHOD 2: If still empty, try window.CodeMirror instances
  if ((!schemaSQL || !querySQL) && window.CodeMirror) {
    console.log('Trying window.CodeMirror instances...');
    
    // Get all CodeMirror instances from the global object
    if (window.CodeMirror.instances && window.CodeMirror.instances.length > 0) {
      window.CodeMirror.instances.forEach((instance, index) => {
        try {
          const value = instance.getValue();
          console.log(`Global instance ${index}:`, value.length, 'chars');
          
          if (index === 0 && !schemaSQL) {
            schemaSQL = value;
          } else if (index === 1 && !querySQL) {
            querySQL = value;
          }
        } catch (e) {
          console.log(`Global instance ${index} error:`, e.message);
        }
      });
    }
  }
  
  // METHOD 3: Execute in page context to bypass any restrictions
  if (!schemaSQL || !querySQL) {
    console.log('Trying page context execution...');
    
    // Create a script element to run in page context
    const script = document.createElement('script');
    script.textContent = `
      (function() {
        try {
          const result = {schema: '', query: ''};
          const editors = document.querySelectorAll('.CodeMirror');
          
          editors.forEach((editor, index) => {
            if (editor.CodeMirror) {
              const value = editor.CodeMirror.getValue();
              if (index === 0) result.schema = value;
              if (index === 1) result.query = value;
            }
          });
          
          // Dispatch event with result
          const event = new CustomEvent('dbfiddleSQLResult', {detail: result});
          document.dispatchEvent(event);
        } catch(e) {
          console.error('Page context error:', e);
        }
      })();
    `;
    
    // Set up event listener
    const handler = function(event) {
      console.log('Received SQL result from page context:', event.detail);
      if (event.detail.schema && !schemaSQL) schemaSQL = event.detail.schema;
      if (event.detail.query && !querySQL) querySQL = event.detail.query;
      document.removeEventListener('dbfiddleSQLResult', handler);
    };
    
    document.addEventListener('dbfiddleSQLResult', handler);
    document.documentElement.appendChild(script);
    script.remove();
    
    // Wait a bit for the script to execute
    return new Promise(resolve => {
      setTimeout(() => {
        console.log('Final SQL lengths:', {
          schema: schemaSQL.length,
          query: querySQL.length
        });
        resolve({schema: schemaSQL, query: querySQL});
      }, 100);
    });
  }
  
  console.log('SQL extraction complete:', {
    schema: schemaSQL.length,
    query: querySQL.length
  });
  
  return Promise.resolve({schema: schemaSQL, query: querySQL});
}

// Function to download file
function downloadFile(filename, content) {
  const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
  return true;
}

// Create the download button
function createDownloadButton() {
  // Remove if already exists
  const existing = document.getElementById('dbfiddle-download-btn');
  if (existing) existing.remove();
  
  // Create button
  const btn = document.createElement('button');
  btn.id = 'dbfiddle-download-btn';
  btn.innerHTML = 'Save SQL';
  
  // Style button
  btn.style.cssText = `
    position: fixed !important;
    top: 80px !important;
    right: 20px !important;
    z-index: 100000 !important;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%) !important;
    color: white !important;
    border: none !important;
    padding: 12px 20px !important;
    border-radius: 8px !important;
    cursor: pointer !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    font-size: 14px !important;
    font-weight: 600 !important;
    box-shadow: 0 4px 15px rgba(0,0,0,0.2) !important;
    transition: all 0.3s ease !important;
    letter-spacing: 0.5px !important;
  `;
  
  // Hover effects
  btn.addEventListener('mouseenter', () => {
    btn.style.transform = 'translateY(-2px) scale(1.05)';
    btn.style.boxShadow = '0 8px 25px rgba(0,0,0,0.3)';
  });
  
  btn.addEventListener('mouseleave', () => {
    btn.style.transform = 'translateY(0) scale(1)';
    btn.style.boxShadow = '0 4px 15px rgba(0,0,0,0.2)';
  });
  
  // Click handler
  btn.addEventListener('click', async function() {
    console.log('Download button clicked');
    
    // Change button to loading state
    const originalHTML = btn.innerHTML;
    btn.innerHTML = '⏳ Extracting...';
    btn.style.opacity = '0.8';
    btn.style.cursor = 'wait';
    
    try {
      // Get SQL content
      const sql = await getSQLFromPage();
      
      if (!sql.schema && !sql.query) {
        throw new Error('No SQL code found in editors');
      }
      
      // Create combined content with simple separators
      const separator = '\n\n<<<<< Query SQL >>>>>\n\n';
      
      let combinedContent = '';
      
      if (sql.schema) {
        combinedContent += '<<<<< Schema SQL >>>>>\n\n' + sql.schema;
      }
      
      if (sql.query) {
        combinedContent += (combinedContent ? separator : '') + sql.query;
      }
      
      // Generate simple filename with counter
      function getNextFilename() {
        // Try to get existing counter from localStorage
        let counter = localStorage.getItem('dbfiddle_counter') || 1;
        
        // Generate filename
        const filename = `db_fiddle_${counter}.txt`;
        
        // Increment counter for next time
        localStorage.setItem('dbfiddle_counter', parseInt(counter) + 1);
        
        return filename;
      }
      
      const filename = getNextFilename();
      
      // Download
      downloadFile(filename, combinedContent);
      
      // Success feedback
      btn.innerHTML = '✅ Saved!';
      btn.style.background = 'linear-gradient(135deg, #4CAF50 0%, #2E7D32 100%)';
      
      setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
      }, 1500);
      
    } catch (error) {
      console.error('Download error:', error);
      
      // Error feedback
      btn.innerHTML = '❌ Failed';
      btn.style.background = 'linear-gradient(135deg, #f44336 0%, #c62828 100%)';
      
      setTimeout(() => {
        btn.innerHTML = originalHTML;
        btn.style.background = 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)';
        btn.style.opacity = '1';
        btn.style.cursor = 'pointer';
      }, 2000);
      
      // Show debug info in console
      console.log('DEBUG INFO:');
      console.log('CodeMirror elements found:', document.querySelectorAll('.CodeMirror').length);
      
      // Try to manually access editors
      const editors = document.querySelectorAll('.CodeMirror');
      editors.forEach((editor, i) => {
        console.log(`\nEditor ${i}:`);
        console.log('  - Has .CodeMirror:', !!editor.CodeMirror);
        console.log('  - Has textarea:', !!editor.querySelector('textarea'));
        console.log('  - Class:', editor.className);
        
        // Try to access the value
        if (editor.CodeMirror) {
          try {
            const value = editor.CodeMirror.getValue();
            console.log('  - Value length:', value.length);
            console.log('  - Preview:', value.substring(0, 100).replace(/\n/g, '\\n'));
          } catch (e) {
            console.log('  - Error accessing:', e.message);
          }
        }
      });
    }
  });
  
  // Add button to page
  document.body.appendChild(btn);
  console.log('Download button created');
  
  return btn;
}

// Initialize
function initializeExtension() {
  console.log('Initializing extension...');
  
  // Wait for page to be fully loaded
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      setTimeout(createDownloadButton, 1000);
    });
  } else {
    setTimeout(createDownloadButton, 1000);
  }
}

// Start the extension
initializeExtension();

// Also add button when URL changes (for SPAs)
let lastUrl = location.href;
new MutationObserver(() => {
  const url = location.href;
  if (url !== lastUrl) {
    lastUrl = url;
    console.log('URL changed, reinitializing...');
    setTimeout(createDownloadButton, 1500);
  }
}).observe(document, { subtree: true, childList: true });

// Add debug helper to window
window.dbfiddleHelper = {
  test: function() {
    console.log('=== DBFIDDLE HELPER TEST ===');
    const editors = document.querySelectorAll('.CodeMirror');
    console.log('Total .CodeMirror elements:', editors.length);
    
    editors.forEach((editor, i) => {
      console.log(`\n--- Editor ${i} ---`);
      console.log('Element:', editor);
      console.log('Has .CodeMirror property:', !!editor.CodeMirror);
      
      if (editor.CodeMirror) {
        try {
          const value = editor.CodeMirror.getValue();
          console.log('Value length:', value.length);
          console.log('First 200 chars:', value.substring(0, 200));
          
          // Try to determine content type
          const lowerValue = value.toLowerCase();
          if (lowerValue.includes('create') || lowerValue.includes('insert')) {
            console.log('Likely: SCHEMA SQL');
          } else if (lowerValue.includes('select')) {
            console.log('Likely: QUERY SQL');
          }
        } catch (e) {
          console.log('Error getting value:', e.message);
        }
      }
    });
    
    // Also check window.CodeMirror
    if (window.CodeMirror) {
      console.log('\n--- window.CodeMirror ---');
      console.log('Instances:', window.CodeMirror.instances);
    }
  },
  
  forceDownload: function() {
    const btn = document.getElementById('dbfiddle-download-btn');
    if (btn) btn.click();
    else console.log('Button not found, creating...');
    createDownloadButton();
    setTimeout(() => document.getElementById('dbfiddle-download-btn').click(), 500);
  }
};

console.log('DBFiddle Downloader ready! Use dbfiddleHelper.test() to debug.');