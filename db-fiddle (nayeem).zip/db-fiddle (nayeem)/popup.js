document.addEventListener('DOMContentLoaded', function() {
  const downloadBtn = document.getElementById('downloadBtn');
  const downloadSingleBtn = document.getElementById('downloadSingleBtn');
  const statusDiv = document.getElementById('status');
  const includeSeparators = document.getElementById('includeSeparators');
  const includeTimestamps = document.getElementById('includeTimestamps');

  // Function to show status message
  function showStatus(message, isError = false) {
    statusDiv.textContent = message;
    statusDiv.className = 'status ' + (isError ? 'error' : 'success');
    setTimeout(() => {
      statusDiv.style.display = 'none';
    }, 3000);
  }

  // Function to execute script in active tab
  function executeScript(action, callback) {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if (tabs[0]) {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: action,
          options: {
            includeSeparators: includeSeparators.checked,
            includeTimestamps: includeTimestamps.checked
          }
        }, function(response) {
          if (chrome.runtime.lastError) {
            showStatus('Please navigate to DBFiddle first!', true);
          } else if (response && response.success) {
            callback(response);
          } else {
            showStatus('Failed to extract SQL code', true);
          }
        });
      }
    });
  }

  // Download as separate files
  downloadBtn.addEventListener('click', function() {
    executeScript('downloadSeparate', function(response) {
      if (response.files.length > 0) {
        showStatus(`Downloaded ${response.files.length} file(s)`);
      }
    });
  });

  // Download as single combined file
  downloadSingleBtn.addEventListener('click', function() {
    executeScript('downloadCombined', function(response) {
      if (response.filename) {
        showStatus('Combined file downloaded!');
      }
    });
  });
});